#!/bin/bash
echo "Entrando en modo monousuario..."
sudo sulogin

