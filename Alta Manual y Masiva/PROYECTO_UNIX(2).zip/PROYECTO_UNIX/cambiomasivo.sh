#!/bin/bash
{
awk -f cambiomasivo.awk contranueva.txt
}
