#!/bin/bash
{
	echo " ****** TIEMPO DE SESION DE LOS USUARIOS ******"
	sleep 1
	echo "FECHA	USUARIO	    TIEMPO TOTAL	     TIEMPO "
	ac -dp
}
