#ejecutar todo con sudo
echo "Se borraran los archivos de tmp"
chmod 777 /tmp/*
pushd /tmp/
rm -r /tmp/*
popd

echo "Cada cuando borrar los archivos de temporales: "
echo " el formato es  min (0-59)"
read  min
echo "Ingrese el formato hr(0-23)"
read h
echo "Indique el dia del mes (1-31)"
read dm
echo  "Ingrese el mes(1-12)"
read mes
echo "Dia de la semana (0-7)"
read ds
echo "$min $h $dm $mes $ds root usermod -U $usuario" | cat>>/etc/crontab


echo "Se han borrado los archivos del directorio tmp"
