#!/bin/bash
echo "--------------TAREAS DE MANTENIMIENTO Y NIVELES DE ARRANQUE-----------"
echo "BIENVENIDO AL QUEQUEO DE VOLUMENES..."
echo "Que voluen desea checar ?"
read volum
sleep 3

echo "Desmontando para chequeo...(bajo su propio riesgo)"
umount $volum
echo "Checando volumen..."
fsck $volum
echo "Montando en donde estaba..."
mount $volum
