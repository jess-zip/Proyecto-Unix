#!/bin/bash
echo "***** CREAR IN BACKUP *****"
sleep 1
echo "Direccion del nombre del archivo (.tar): "
read e1
echo "Realizando backup......"
sleep 1
echo "Direccion de la carpeta a guardar : "
read e2


echo "Cada cuando crear el backup"
echo " el formato es  min (0-59)"
read  min
echo "Ingrese el formato hr(0-23)"
read h
echo "Indique el dia del mes (1-31)"
read dm
echo  "Ingrese el mes(1-12)"
read mes
echo "Dia de la semana (0-7)"
read ds
echo "$min $h $dm $mes $ds root tar -cvzf $e1 $e2" | cat>>/etc/crontab



#tar -cvzf $e1 $e2
echo "**** BACKUP RELIZADO CON EXITO ****"
