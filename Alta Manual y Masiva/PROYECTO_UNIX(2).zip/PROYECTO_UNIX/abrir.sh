#!/bin/bash
clear
read -p "¿Cuál programa quiere abrir? " prog

$prog #ejecutando el programa

clear