#!/bin/bash
clear
{
echo " *** INGRESE EL USUARIO PARA VER SUS PROCESOS ***"
read  usrr
ps aux | grep $usrr
}
