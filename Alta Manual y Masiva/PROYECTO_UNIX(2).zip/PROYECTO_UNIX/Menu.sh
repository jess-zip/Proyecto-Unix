#!/bin/bash

# Muestra el menu general
_menu()
{
    clear
echo "--------------------------------- MENU ----------------------------------"
echo "1. ADMINISTRACION DE USUARIOS--------------------------------------------"
echo "11) Alta masiva de usuarios, via archivo de texto"
echo "12) Alta manual de usuarios"
echo "13) Cambio masivo de contrasena, via archivo de texto"
echo "14) Cambio manual de contrasena" 
echo "2. PROGRAMACION DE TAREAS-------------------------------------------------"
echo "21) Programacion de tareas manual"
echo "22) Respaldo programado"
echo "23) Borrado de temporales programado" 
echo "24) Inhabilitacion de usuarios, por periodo de tiempo (incluso hrs y min)"
echo "3. TAREAS DE MANTENIMINETO Y NIVELS DE ARRANQUE---------------------------"
echo "31) HAbilitar/Inhablitar chequeo en volumenes"
echo "32) Arranque en modo mantenimiento (Monousuario)"
echo "33) Arranque manual (Modo)"
echo "34) Creacion, formato y montaje de volumenes"
echo "4. TAREAS SOBRE USUARIOS EN SESION----------------------------------------"
echo "41) Monitorear los inicio/termino de sesion de un usuario"
echo "42) Respaldo de carpetas al iniciar sesion un usuario"
echo "43) Monitoreo de aplicaciones ejecutadas por el usuario"
echo "44) Tiempo de sesion"
echo "5. PROPUESTAS-------------------------------------------------------------"
echo "51) Papelera de reciclaje"
echo "52) Administrador de arhivos"
echo "53) Instalar/Desinstalar un programa y/o aplicaion"
echo "6. SALIR------------------------------------------------------------------"
echo "--------------------------------------------------------------------------"
echo -n "Opcion: "
#read op
}

#opcion por defecto
op="0"

until [ "$op" -eq "6" ];
do
case $op in
    11) clear
	
        #_menu
	./UsariosMasivos.sh
	;;

    12) clear
	./AltaUserManual.sh
	;;

    13) clear
	./cambiomasivo.sh
	
	# _menu
	;;

    14) clear
	./cambioManualContra.sh
	
	#_menu
	;;
    
    21) clear
	./ProgTarMan.sh
	# _menu
	;;

    22) clear
	./RespaldoProgramado.sh
	#_menu
	;;

    23) clear
	./Borradotmp.sh
	#_menu
	;;

    24) clear
	./inhabilitarUsr.sh
	;;
    
    31) clear
	./Habi.Inha_Volum.sh
	#_menu
	;;

    32) clear
	./monousuario.sh
	#_menu
	;;

    33) clear
	./ArranqueManual.sh
	
	#_menu
	;;

    34) clear
	echo "no esta jejeje"
	#_menu
	;;

    41) clear
	./monitoreoUsuarios.sh
	#_menu
	;;

    42) clear
	echo "tampoco esta jjejeeje"
	#_menu
	;;

    43) clear
	./ProcesosPorUsuario.sh	
	#_menu
	;;

    44) clear
	./TiempoConexion.sh
	
	#_menu
	;;

    51) clear
	echo "No estoy aqui, busca despues..."
	#_menu
	;;

    52) clear
	echo "No estoy aqui, busca despues..."
	#_menu
	;;

    53) clear
	echo "No estoy aqui, busca despues..."
	 #_menu
	;;

    *) clear
	 echo "Opcion no valida"
    #sleep 3
    #clear
	 _menu
	 ;;
esac
	
read op

done

