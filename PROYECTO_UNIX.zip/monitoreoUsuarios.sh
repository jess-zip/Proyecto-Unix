#!/bin/bash
{
echo " ***** MONITOREO DEL INICIO Y TERMINO DE SECION DE LOS USUARIOS ***** "
echo "USUARIO	 TERMINAL     HOST DE INGRESO  FECHA DE INGRESO - SALIDA TIEMPO"
last
echo " ******************************************************************** "
}
