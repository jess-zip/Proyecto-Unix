#!/bin/bash
{
	echo " ****** TIEMPO DE SESION DE LOS USUARIOS ******"
	sleep 1
	echo "FECHA	USUARIO		TIMEPO TOTAL	     TIEMPO "
	ac -dp
}
